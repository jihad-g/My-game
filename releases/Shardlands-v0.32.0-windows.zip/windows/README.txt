Shardlands v0.32.0
====================

1. Unzip anywhere.
2. Start the game: double-click Shardlands.exe
3. The game is not code-signed yet. On Windows, if SmartScreen says "Windows protected
   your PC", click "More info" -> "Run anyway".

Needs a graphics card with Vulkan support (or start with --rendering-driver opengl3).
Saves: Windows %APPDATA%\Godot\app_userdata\Shardlands  ·  Linux ~/.local/share/godot/app_userdata/Shardlands
Press F1 in the game for the guide. If the game ever crashes, a report is written
to the crash_reports folder next to your saves - please send it to us.
